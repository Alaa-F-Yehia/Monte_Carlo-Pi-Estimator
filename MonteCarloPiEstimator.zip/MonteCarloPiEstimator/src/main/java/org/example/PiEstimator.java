package org.example;

public interface PiEstimator {

    double estimatePi(long totalPoints) throws Exception;
}

